<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HeaderVoucher extends Model
{
    //
}
